package com.admob.android.ads;

import org.json.JSONObject;

abstract interface s
{
  public abstract String h();
  
  public abstract JSONObject i();
}


/* Location:              F:\Java\android-giro-gamer\Decompile\1\doodle_dex2jar.jar!\com\admob\android\ads\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */