package com.admob.android.ads;

public class SimpleAdListener
  implements AdListener
{
  public void onFailedToReceiveAd(AdView paramAdView) {}
  
  public void onFailedToReceiveRefreshedAd(AdView paramAdView) {}
  
  public void onReceiveAd(AdView paramAdView) {}
  
  public void onReceiveRefreshedAd(AdView paramAdView) {}
}


/* Location:              F:\Java\android-giro-gamer\Decompile\1\doodle_dex2jar.jar!\com\admob\android\ads\SimpleAdListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */