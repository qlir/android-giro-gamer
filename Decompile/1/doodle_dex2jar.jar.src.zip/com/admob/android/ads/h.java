package com.admob.android.ads;

public abstract interface h
{
  public abstract void a(r paramr);
  
  public abstract void a(r paramr, Exception paramException);
}


/* Location:              F:\Java\android-giro-gamer\Decompile\1\doodle_dex2jar.jar!\com\admob\android\ads\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */