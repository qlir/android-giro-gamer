package com.realarcade.DOJ;

class VideoCallback
  implements Runnable
{
  public static final int ANDROID_GAMEVIEW = 0;
  public static final int ANDROID_VIDEOVIEW = 1;
  
  public void run() {}
}


/* Location:              F:\Java\android-giro-gamer\Decompile\1\doodle_dex2jar.jar!\com\realarcade\DOJ\VideoCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */