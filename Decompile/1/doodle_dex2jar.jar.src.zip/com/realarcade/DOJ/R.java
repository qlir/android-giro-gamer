package com.realarcade.DOJ;

public final class R
{
  public static final class attr {}
  
  public static final class drawable
  {
    public static final int i = 2130837504;
  }
  
  public static final class layout
  {
    public static final int main = 2130903040;
  }
  
  public static final class raw
  {
    public static final int sfx_0 = 2130968576;
    public static final int sfx_1 = 2130968577;
    public static final int sfx_2 = 2130968578;
    public static final int sfx_3 = 2130968579;
    public static final int sfx_4 = 2130968580;
  }
  
  public static final class string
  {
    public static final int MIDlet_1 = 2131034116;
    public static final int MIDlet_Icon = 2131034117;
    public static final int MIDlet_Jar_Size = 2131034119;
    public static final int MIDlet_Jar_URL = 2131034120;
    public static final int MIDlet_Name = 2131034113;
    public static final int MIDlet_Vendor = 2131034115;
    public static final int MIDlet_Version = 2131034114;
    public static final int MicroEdition_Profile = 2131034118;
    public static final int app_name = 2131034112;
  }
}


/* Location:              F:\Java\android-giro-gamer\Decompile\1\doodle_dex2jar.jar!\com\realarcade\DOJ\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */